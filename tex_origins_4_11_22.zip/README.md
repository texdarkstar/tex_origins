# tex_origins
Custom made origins for minecraft made with the origins mod.


Current origins are:
| Origin | Impact  |
| ------ | ------- |
| Lich   | 3       |
| Giant  | 3       |
| Dwarf  | 3       |

